package fi.dy.masa.litematica.render;

import java.util.List;
import org.joml.Matrix4fc;
import org.jspecify.annotations.Nullable;

import com.mojang.blaze3d.buffers.GpuBufferSlice;
import com.mojang.blaze3d.textures.GpuSampler;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.Camera;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.block.BlockAndTintGetter;
import net.minecraft.client.renderer.block.FluidRenderer;
import net.minecraft.client.renderer.block.dispatch.BlockStateModel;
import net.minecraft.client.renderer.block.dispatch.BlockStateModelPart;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderDispatcher;
import net.minecraft.client.renderer.chunk.ChunkSectionLayerGroup;
import net.minecraft.client.renderer.culling.Frustum;
import net.minecraft.client.renderer.entity.EntityRenderDispatcher;
import net.minecraft.client.renderer.fog.FogRenderer;
import net.minecraft.client.renderer.state.level.CameraRenderState;
import net.minecraft.client.renderer.state.level.LevelRenderState;
import net.minecraft.core.BlockPos;
import net.minecraft.util.LightCoordsUtil;
import net.minecraft.util.RandomSource;
import net.minecraft.util.debug.DebugValueAccess;
import net.minecraft.util.profiling.ProfilerFiller;
import net.minecraft.world.level.LightLayer;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.phys.Vec3;

import fi.dy.masa.malilib.render.uniform.ChunkFixUniform;
import fi.dy.masa.litematica.render.schematic.*;
import fi.dy.masa.litematica.util.invoker.IEntityHitboxDebugRendererInvoker;
import fi.dy.masa.litematica.world.ChunkSchematicState;
import fi.dy.masa.litematica.world.WorldSchematic;

/**
 * The purpose of adding this as an Interface is so that we can
 * test a "replacement" Schematic World Renderer system in the future;
 * more easily using this common interface via {@link LitematicaRenderer}
 * without needing to change almost any other code.
 * <br>
 * The goal with any future Renderer is to off load *all* Meshing
 * tasks into a separate thread; while maintaining the drawing, and
 * resorting tasks in the Game's Rendering thread; along with anything
 * else that is calling {@link com.mojang.blaze3d.systems.RenderSystem};
 * such as building the {@link com.mojang.blaze3d.buffers.GpuBuffer} objects.
 */
public interface IWorldSchematicRenderer
{
	void markNeedsUpdate();

	boolean hasWorld();

	String getDebugInfoRenders();

	String getDebugInfoEntities();

	ProfilerFiller getProfiler();

	ChunkRenderGpuDispatcher getChunkRendererGpuDispatcher();

	BlockEntityRenderDispatcher getBlockEntityRenderer();

	EntityRenderDispatcher getEntityRenderer();

	FogRenderer getFogRenderer();

	SchematicRenderState getSchematicRenderState();

	void setWorldAndLoadRenderers(@Nullable WorldSchematic world);

	void loadRenderers(@Nullable ProfilerFiller profiler);

	void reloadBlockRenderManager();

	void updateCameraState(Camera camera, float tickProgress, CameraRenderState cameraState);

	void setupTerrain(Camera camera, Frustum frustum, int frameCount, boolean playerSpectator, ProfilerFiller profiler);

	void updateChunks(long finishTimeNano, ProfilerFiller profiler);

	void capturePreMainValues(CameraRenderState camera, GpuBufferSlice fogBuffer, ProfilerFiller profiler);

	void uploadRemainingBuffers(long finishTimeNano, DeltaTracker deltaTracker, double cameraX, double cameraY, double cameraZ, ProfilerFiller profiler);

	int prepareBlockLayers(Matrix4fc matrix4fc, double cameraX, double cameraY, double cameraZ, ProfilerFiller profiler);

	<T extends Comparable<T>> BlockState getFallbackState(BlockState origState);

	@Nullable BlockStateModel getModelForState(BlockState state);

	List<BlockStateModelPart> getModelParts(BlockPos pos, BlockState state, RandomSource rand);

	boolean renderBlock(BlockModelRendererSchematic renderer, BlockAndTintGetter world, BlockState state, BlockPos pos, Vec3 offset, IBlockOutputSchematic output);

	boolean renderFluid(FluidModelRendererSchematic renderer, BlockAndTintGetter world, BlockState blockState, FluidState fluidState, BlockPos pos, FluidRenderer.Output output, final float offsetY);

	void drawBlockLayerGroup(ChunkSectionLayerGroup group, @Nullable GpuSampler sampler);

	void scheduleTranslucentSorting(Vec3 cameraPos, ProfilerFiller profiler);

	void prepareEntities(Camera camera, Frustum frustum, LevelRenderState renderStates, DeltaTracker tickCounter, ProfilerFiller profiler);

	void renderEntities(Camera camera, Frustum frustum, PoseStack matrices, LevelRenderState renderStates, SubmitNodeCollector queue, ProfilerFiller profiler);

	void prepareBlockEntities(Camera camera, Frustum frustum, LevelRenderState renderStates, PoseStack matrices, float tickProgress, ProfilerFiller profiler);

	void renderBlockEntities(Camera camera, Frustum frustum, PoseStack matrices, LevelRenderState renderStates, SubmitNodeCollector queue, ProfilerFiller profiler);

//	void updateBlockEntities(Collection<BlockEntity> toRemove, Collection<BlockEntity> toAdd);

	void renderBlockOverlays(Camera camera, float lineWidth, ProfilerFiller profiler);

	void scheduleChunkRenders(int chunkX, int chunkZ, boolean immediate);

	ChunkSchematicState getChunkSchematicState(int chunkX, int chunkZ);

	void setChunkSchematicState(int chunkX, int chunkZ, ChunkSchematicState state);

	ChunkFixUniform getChunkFixUniform();

//	LegacyTerrainFixUniform getLegacyTerrainFixUniform();

	GpuSampler getGpuSampler();

	void closeGpuSampler();

	void clearChunkFixUniform();

//	void clearLegacyTerrainFixUniform();

	void clearWorldRenderStates();

	void renderEntityDebugHitboxes(IEntityHitboxDebugRendererInvoker invoker, double cameraX, double cameraY, double cameraZ, DebugValueAccess debugValueAccess, Frustum frustum, float ticks);

	static int getLightmap(BlockAndTintGetter world, BlockPos pos)
	{
		return getLightmap(LightGetter.DEFAULT, world, world.getBlockState(pos), pos);
	}

	static int getLightmap(LightGetter getter, BlockAndTintGetter world, BlockState state, BlockPos pos)
	{
		if (state.emissiveRendering())
		{
			return 15728880;
		}

		int light = getter.packedLight(world, pos);
		int blockLight = LightCoordsUtil.block(light);
		int luminance = state.getLightEmission();

		if (blockLight < luminance)
		{
			return LightCoordsUtil.withBlock(light, luminance);
		}

		return light;
	}

	@FunctionalInterface
	interface LightGetter
	{
		LightGetter DEFAULT = (world, pos) ->
				LightCoordsUtil.pack(world.getBrightness(LightLayer.BLOCK, pos), world.getBrightness(LightLayer.SKY, pos));

		int packedLight(BlockAndTintGetter world, BlockPos pos);
	}
}
