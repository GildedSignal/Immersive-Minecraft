package com.thedeathlycow.immersive.storms.particle;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.particle.DustParticleBase;
import net.minecraft.client.particle.Particle;
import net.minecraft.client.particle.ParticleProvider;
import net.minecraft.client.particle.SpriteSet;
import net.minecraft.util.RandomSource;
import org.jetbrains.annotations.Nullable;

public class DustGrainParticle extends DustParticleBase<DustGrainParticleEffect> {
    public DustGrainParticle(
            ClientLevel world,
            double x, double y, double z,
            double velocityX, double velocityY, double velocityZ,
            DustGrainParticleEffect parameters,
            SpriteSet spriteProvider
    ) {
        super(world, x, y, z, velocityX, velocityY, velocityZ, parameters, spriteProvider);
        this.xd = velocityX;
        this.yd = velocityY;
        this.zd = velocityZ;
        this.gravity = 1e-1f;

        float multiplier = this.random.nextFloat() * 0.4F + 0.6F;
        this.rCol = this.randomizeColor(parameters.getColor().x(), multiplier);
        this.gCol = this.randomizeColor(parameters.getColor().y(), multiplier);
        this.bCol = this.randomizeColor(parameters.getColor().z(), multiplier);
    }

    @Environment(EnvType.CLIENT)
    public static class Provider implements ParticleProvider<DustGrainParticleEffect> {
        private final SpriteSet sprite;

        public Provider(SpriteSet sprite) {
            this.sprite = sprite;
        }

        @Override
        public @Nullable Particle createParticle(
                DustGrainParticleEffect parameters,
                ClientLevel world,
                double x, double y, double z,
                double velocityX, double velocityY, double velocityZ,
                RandomSource random
        ) {
            return new DustGrainParticle(
                    world,
                    x, y, z,
                    velocityX, velocityY, velocityZ,
                    parameters,
                    this.sprite
            );
        }
    }
}