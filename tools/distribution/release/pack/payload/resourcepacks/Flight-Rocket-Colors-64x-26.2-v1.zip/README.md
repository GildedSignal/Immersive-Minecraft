# Flight Rocket Colors — 64x, Minecraft Java 26.2

Flight duration **1 = red**, **2 = blue**, **3 = violet**. Paper stripes, wooden stick, pixel shading, texture size and silhouette match the current Faithful 64x rocket. Duration 1 stays the original red. Other/missing durations use the underlying resource pack's normal rocket.

This is a native resource pack. No mod, CIT, server change, command, custom item data, or changed crafting recipe is needed. The item definition reads the existing `minecraft:fireworks` flight duration using `minecraft:component` predicates. The explosion list is not tested, so rockets with firework stars still get the correct duration color. Fireworks, Elytra thrust, sounds, explosions, item names and tooltips retain their behavior.

The included Faithful texture is copied unmodified; Minecraft's `paletted_permutations` atlas source recolors only its five red colors when resources load. The tiny palette PNGs encode lookup tables. There is no per-frame texture generation and no new shader.

## Installation

The ZIP is already copied to the Fabric 26.2 instance's `resourcepacks` folder. At a convenient pause, open Options → Resource Packs, enable **Flight-Rocket-Colors-64x-26.2-v1.zip**, and put it above Faithful and any pack that customizes rocket item models. Applying packs triggers a resource reload; it can briefly freeze the game. This task does not force a reload while you play.

Pack ID in `options.txt`: `file/Flight-Rocket-Colors-64x-26.2-v1.zip`. Minecraft stores the enabled list from lower priority to higher priority, so this should be the final file entry in that list. Remove the pack to restore the underlying rocket appearance.

## Verification

Inspect or craft one-, two-, and three-gunpowder rockets; the tooltip's Flight Duration should match the red/blue/violet item color. Check inventory, held item, dropped item and a rocket launched from a dispenser. Try an explosion rocket too. The colors describe duration; they do not indicate whether a rocket is safe for Elytra use. The crossbow's separate loaded-firework sprite is unchanged.

Optional commands in a test world where cheats are enabled:

```mcfunction
/give @s minecraft:firework_rocket[minecraft:fireworks={flight_duration:1,explosions:[]}] 1
/give @s minecraft:firework_rocket[minecraft:fireworks={flight_duration:2,explosions:[]}] 1
/give @s minecraft:firework_rocket[minecraft:fireworks={flight_duration:3,explosions:[]}] 1
/give @s minecraft:firework_rocket[minecraft:fireworks={flight_duration:3,explosions:[{shape:"small_ball",colors:[16711680]}]}] 1
```

`build_pack.py` rebuilds and installs the pack. `validate_pack.py` checks ZIP layout, metadata, palettes, alpha/silhouette preservation, references and source-copy integrity. `reference/RocketCodecCheck.java` checks the item definition, atlas definitions, metadata and duration matching using the installed game's own codecs. See `validation.json` and `reference/codec-check.log` for results. Visual/in-game validation is separate and must not be claimed until a resource reload and duration check has been completed.

## Attribution and compatibility

Rocket artwork is the unchanged firework rocket texture from **Faithful 64x — Release 14**, credited to **HARYA_ and many others**. [Faithful website](https://faithfulpack.net/). The original license is included as `LICENSE-Faithful.txt`. This is an unofficial personal add-on.

Native component model predicates are documented in [Mojang's 1.21.5 release notes](https://www.minecraft.net/en-us/article/minecraft-java-edition-1-21-5). Compatibility is pinned to the installed Minecraft 26.2 `version.json` resource format **88.0**. The selector and palette codec were also inspected in the installed 26.2 jar, rather than inferred from older CIT guides. Other versions are not claimed.
