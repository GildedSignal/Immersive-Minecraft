#version 330 compatibility

const float shadowDistanceRenderMul = 1.0;
const float entityShadowDistanceMul = 0.5;
const bool shadowHardwareFiltering0 = true;

#include "/programs/composite/Composite13.frag"
