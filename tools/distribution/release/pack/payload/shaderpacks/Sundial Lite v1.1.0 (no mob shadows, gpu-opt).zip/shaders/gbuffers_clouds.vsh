#version 330 compatibility

#include "/programs/gbuffers/Cloud.vert"